<?php

$sugar_config['addAjaxBannedModules'][] = "asol_Reports";

$app_list_strings['moduleList']['asol_Reports'] = 'Informes';

$app_strings['LBL_DASHLET_REPORTCHART'] = 'Informes AlineaSol';
$app_strings['LBL_DASHLET_REPORTCHART_DESC'] =  'Informes AlineaSol';
$app_strings['LBL_DASHLET_REPORTCHART_REPORTID'] =  'Selecciona Informe';

?>