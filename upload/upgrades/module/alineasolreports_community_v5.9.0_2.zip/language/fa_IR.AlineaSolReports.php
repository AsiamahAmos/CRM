<?php

$sugar_config['addAjaxBannedModules'][] = "گزارشات";

$app_list_strings['moduleList']['asol_Reports'] = 'گزارشات';

$app_strings['LBL_DASHLET_REPORTCHART'] = 'گزارشات';
$app_strings['LBL_DASHLET_REPORTCHART_DESC'] =  'گزارشات';
$app_strings['LBL_DASHLET_REPORTCHART_REPORTID'] =  'انتخاب گزارش';

?>