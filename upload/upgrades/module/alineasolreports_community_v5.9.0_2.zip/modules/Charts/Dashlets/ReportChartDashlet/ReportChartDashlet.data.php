<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$dashletData['ReportChartDashlet']['searchFields'] = array(

	'which_chart' => array(
		'name'  => 'which_chart',
		'vname' => 'LBL_WHICH_CHART',
		'type'  => 'enum',
		'options' => array(),
	),
	
)

?>