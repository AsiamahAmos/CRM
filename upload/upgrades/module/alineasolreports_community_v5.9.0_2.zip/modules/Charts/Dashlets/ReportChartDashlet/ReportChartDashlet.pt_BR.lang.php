<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$dashletStrings['ReportChartDashlet'] = array(
	'LBL_TITLE' => 'Relatórios AlineaSol',
	'LBL_WHICH_CHART' => 'Escolher Relatório',
	'LBL_REPORT_NAME' => 'Nome do Relatório',
	'LBL_REPORT_MODULE' => 'Módulo do Relatório',
	'LBL_REPORT_SCOPE' => 'Âmbito do Relatório',
	'LBL_REPORT_SEARCH' => 'Pesquisar',
	'LBL_REPORT_SCOPE_ALL' => 'Tudo',
	'LBL_REPORT_SCOPE_PUBLIC' => 'Público',
	'LBL_REPORT_SCOPE_PRIVATE' => 'Privado',
	'LBL_REPORT_SCOPE_ROLE' => 'Função',
	'LBL_DESCRIPTION' => 'Gráfico Configurável Personalizado',
	'LBL_REFRESH' => 'Actualizar Gráfico',
);

?>
