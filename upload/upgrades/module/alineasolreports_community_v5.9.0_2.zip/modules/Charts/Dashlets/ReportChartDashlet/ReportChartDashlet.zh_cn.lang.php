<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$dashletStrings['ReportChartDashlet'] = array(
	'LBL_TITLE' => 'AlineaSol报表',
	'LBL_WHICH_CHART' => '选择报表',
	'LBL_REPORT_NAME' => '报表名称',
	'LBL_REPORT_MODULE' => '报表模块',
	'LBL_REPORT_SCOPE' => '报表范围',
	'LBL_REPORT_SEARCH' => '查找',
	'LBL_REPORT_SCOPE_ALL' => '全部',
	'LBL_REPORT_SCOPE_PUBLIC' => '公用',
	'LBL_REPORT_SCOPE_PRIVATE' => '私用',
	'LBL_REPORT_SCOPE_ROLE' => '角色',
	'LBL_DESCRIPTION' => '自定义图表',
	'LBL_REFRESH' => '刷新图表',
);

?> 
