<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$dashletStrings['ReportChartDashlet'] = array(
	'LBL_TITLE' => 'Informes AlineaSol',
	'LBL_WHICH_CHART' => 'Selecciona Informe',
	'LBL_REPORT_NAME' => 'Nombre del Informe',
	'LBL_REPORT_MODULE' => 'M&oacute;dulo del Informe',
	'LBL_REPORT_SCOPE' => 'Alcance del Informe',
	'LBL_REPORT_SEARCH' => 'Buscar',
	'LBL_REPORT_SCOPE_ALL' => 'Todo',
	'LBL_REPORT_SCOPE_PUBLIC' => 'P&uacute;blico',
	'LBL_REPORT_SCOPE_PRIVATE' => 'Privado',
	'LBL_REPORT_SCOPE_ROLE' => 'Rol',
	'LBL_DESCRIPTION' => 'G&aacute;fico Configurable sobre Informes',
	'LBL_REFRESH'     => 'Actualizar Dashlet',
);

?> 
