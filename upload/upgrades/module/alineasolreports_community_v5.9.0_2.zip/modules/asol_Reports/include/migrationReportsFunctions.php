<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('modules/asol_Common/include/commonUtils.php');

class asol_ReportsMigrationFunctions {
	
	static public function migrateDescriptionToJson($reportDescription) {
		
		if (!empty($reportDescription)) {
			$serialized = base64_decode($reportDescription); // decoding fail => return false
			if ($serialized != false) {
				$unserialized = unserialize($serialized); // unserializing fail => return null
				if ($unserialized != null) {
					return $reportDescription;
				}
			}
		}
		
		$publicDescription = trim($reportDescription);
		$descriptionArray = array(
			'internal' => null,
			'public' => (empty($publicDescription) ? null : $publicDescription),
		);
		
		return base64_encode(serialize($descriptionArray));
		
	}
	
	static public function migrateFieldsDefinitionToJson($reportFields, $reportModule) {

		$isBase64 = (base64_encode(base64_decode($reportFields)) === $reportFields);
		$isJson = json_decode(rawurldecode($reportFields), true);
		
		if ($isBase64 || isset($isJson)) {
	
			return $reportFields;
		
		} else {
			
			$tableModuleArray = self::getTableModuleArray();
			
			$fieldsVersion = substr(substr($reportFields, -9), 3, 5);
			$fieldsValues = substr($reportFields, 0, -9);
			$escapeTokensStringFields = ($fieldsVersion < '1.3.1') ? false : true;
			$fieldsValues = self::unescapeSpecialCases($fieldsValues);
			
			$fields = ($escapeTokensStringFields ? explode('${pipe}', $fieldsValues) : explode('|', $fieldsValues));
			
			if (strlen($fieldsValues) == 0) {
				$fields = array();
			}
		
			$fieldObject['tables'][0] = array(
				'config' => array(
					'visible' => true,
					'subtotals' => array(
						'visible' => true, 
					),
					'totals' => array(
						'visible' => true, 
					),
				),
				'data' => array(),
				'version' => $fieldsVersion
			);
			
			foreach ($fields as $field) {
				$fieldValues = ($escapeTokensStringFields ? explode('${dp}', $field) : explode(":", $field));
				$functionValues = explode('${comma}', $fieldValues[5]);
				
				// Field module
				$splittedField = explode('.', $fieldValues[0]);
				if (count($splittedField) > 1) {
					if (substr($splittedField[0], -strlen('_cstm')) === '_cstm') {
						$enumTable = substr($splittedField[0], 0, -strlen('_cstm'));
					} else {
						$enumTable = $splittedField[0];
					}
					$currentFieldModule = $tableModuleArray[$enumTable];
					$enumField = $splittedField[1];
				} else {
					$currentFieldModule = $reportModule;
					$enumField = $fieldValues[0];
				}
				
				// Enum Operator & Reference
				$externalTable = explode(" ", $reportModule);
				if ($externalTable[1] == '(External_Table)') {
					$enumOperator = '';
					$enumReference = '';
				} else {
		
					if (in_array($fieldValues[13], array('asolFunction'))) {
						$enumOperator = $fieldValues[12];
						$enumReference = $fieldValues[13];
					} else if (in_array($fieldValues[8], array('enum', 'multienum', 'radioenum'))) {
						$enumArray = self::getEnumReferenceForEnumField($currentFieldModule, $enumField);
						$enumOperator = $enumArray['enumOperator'];
						$enumReference =  $enumArray['enumReference'];
					} else {
						$enumOperator = '';
						$enumReference = '';
					}
				
				}
				
				$fieldObject['tables'][0]['data'][] = array(
					'field' => $fieldValues[0],
					'alias' => $fieldValues[1],
					'visible' => $fieldValues[2],
					'sortDirection' => $fieldValues[3],
					'sortOrder' => $fieldValues[4],
					'function' => $functionValues[0],
					'sql' => (isset($functionValues[1])) ? $functionValues[1] : '',
					'grouping' => $fieldValues[6],
					'groupingOrder' => $fieldValues[7],
					'type' => $fieldValues[8],
					'key' => $fieldValues[9],
					'isRelated' => ($fieldValues[10] === 'true'),
					'index' => $fieldValues[11],
					'enumOperator' => $enumOperator,
					'enumReference' => $enumReference
				);
				
			}
			
			return base64_encode(serialize($fieldObject));
			
		}
		
	}
	
	static public function migrateFiltersDefinitionToJson($reportFilters, $reportModule) {
		
		$isBase64 = (base64_encode(base64_decode($reportFilters)) === $reportFilters);
		$isJson = json_decode(rawurldecode($reportFilters), true);
		
		if ($isBase64 || isset($isJson)) {
	
			return $reportFilters;
		
		} else {
			
			$tableModuleArray = self::getTableModuleArray();
			
			$filtersVersion = substr(substr($reportFilters, -9), 3, 5);
			$filtersValues = substr($reportFilters, 0, -9);
			$escapeTokensStringFilters = ($filtersVersion < '1.3.0') ? false : true;
			
			$filtersValues = self::unescapeSpecialCases($filtersValues);
			
			$filters = ($escapeTokensStringFilters ? explode('${pipe}', $filtersValues) : explode('|', $filtersValues));
			
			if (strlen($filtersValues) == 0) {
				$filters = array();
			}
			
			$filterObject = array(
				'config' => array(
					'initialExecution' => false,
				),
				'data' => array(),
				'version' => $filtersVersion,
			);
			
			foreach($filters as $filter) {
				$filterValues = ($escapeTokensStringFilters ? explode('${dp}', $filter) : explode(":", $filter));
				
				$firstParameter = ($escapeTokensStringFilters ? explode('${dollar}', $filterValues[2]) : explode('$', $filterValues[2]));
				
				
				//*Fix Parameters*//
				$firstParameter[0] = ((in_array($filterValues[4], array('date', 'datetime', "datetimecombo", 'timestamp'))) && ($filterValues[1] == 'between') && ($firstParameter[0] == 'day')) ? 'calendar' : $firstParameter[0];
			
				if ((in_array($filterValues[4], array("date", "datetime", "datetimecombo", "timestamp"))) && (in_array($filterValues[1], array("equals", "not equals", "before date", "after date"))) && ($firstParameter[0] != 'calendar')) {
					$filterValues[3] = $filterValues[2];
					$firstParameter[0] = 'calendar';
				} else if ((in_array($filterValues[4], array("date", "datetime", "datetimecombo", "timestamp"))) && (in_array($filterValues[1], array("between", "not between"))) && ($firstParameter[0] != 'calendar')) {
					$filterValues[3] = $filterValues[2].'${comma}'.$filterValues[3];
					$firstParameter[0] = 'calendar';
				}
				//*Fix Parameters*//
				
				
				// Parameters
				$adittionalParameters = explode('${comma}', $filterValues[3]);
				$secondParameter = (strlen($adittionalParameters[0]) > 0 ? array($adittionalParameters[0]) : array()); 
				$thirdParameter = (count($adittionalParameters) > 1 ? array($adittionalParameters[1]) : array());
				
				
				// Filter module
				$splittedFilter = explode('.', $filterValues[0]);
				if (count($splittedFilter) > 1) {
					if (substr($splittedFilter[0], -strlen('_cstm')) === '_cstm') {
						$enumTable = substr($splittedFilter[0], 0, -strlen('_cstm'));
					} else {
						$enumTable = $splittedFilter[0];
					}
					$currentFilterModule = $tableModuleArray[$enumTable];
					$enumField = $splittedFilter[1];
				} else {
					$currentFilterModule = $reportModule;
					$enumField = $filterValues[0];
				}
				
				// Enum Operator & Reference
				$externalTable = explode(" ", $reportModule);
				if ($externalTable[1] == '(External_Table)') {
					$enumOperator = '';
					$enumReference = '';
				} else {
					if (in_array($filterValues[7], array('asolFunction'))) {
						$enumOperator = $filterValues[7];
						$enumReference = $filterValues[8];
					} else if (in_array($filterValues[4], array('enum', 'multienum', 'radioenum'))) {
						$enumArray = self::getEnumReferenceForEnumField($currentFilterModule, $enumField);
						$enumOperator = $enumArray['enumOperator'];
						$enumReference =  $enumArray['enumReference'];
					} else {
						$enumOperator = '';
						$enumReference = '';
					}
				}
					
				// Related filter
				$isRelated = (($filterValues[5] != "") && ($filterValues[5] != "false"));
				
				// User options
				$userOptions = array();
				if (strlen($filterValues[12]) > 0) {
					foreach(explode(',', $filterValues[12]) as $userOptionString) {
						$tmp = explode('=', $userOptionString);
						$userOptions[] = array(
							'key' => $tmp[0],
							'value' => ((count($tmp) > 1) ? $tmp[1] : null),
						);
					}
				} 
				
				// Logical elements
				$logicalElements = explode(':', $filterValues[13]);
				$logicalParenthesis = $logicalElements[0];
				$logicalOperator = (isset($logicalElements[1]) ? $logicalElements[1] : '');
				
				
				
				
				$filterObject['data'][] = array(
					'field' => $filterValues[0],
					'operator' => $filterValues[1],
					'parameters' => array(
						'first' => $firstParameter,
						'second' => $secondParameter,
						'third' => $thirdParameter,
					),
					'type' => ($filterValues[4] == 'theese' ? 'these' : $filterValues[4]),
					'isRelated' => $isRelated,
					'relationKey' => ($isRelated ? $filterValues[5] : ""),
					'index' => $filterValues[6],
					'enumOperator' => $enumOperator,
					'enumReference' => $enumReference,
					'filterReference' => $filterValues[9],
					'alias' => $filterValues[10],
					'behavior' => $filterValues[11],
					'userOptions' => $userOptions,
					'logicalOperators' => array(
						'parenthesis' => $logicalParenthesis,
						'operator' => $logicalOperator,
					),
				);
				
			}
			
			return base64_encode(serialize($filterObject));
			
		}
		
	}
	
	static public function migrateChartsDefinitionToJson($reportChartsDetail) {

		$isBase64 = (base64_encode(base64_decode($reportChartsDetail)) === $reportChartsDetail);
		$isJson = json_decode(rawurldecode($reportChartsDetail), true);
		
		if ($isBase64 || isset($isJson)) {

			return $reportChartsDetail;
		
		} else {
		
			$chartVersion = substr($reportChartsDetail, -9);
			$reportCharts = explode('${pipe}', substr($reportChartsDetail, 0, -9));
			
			$reportChartsJson = '{"charts":[';
			foreach ($reportCharts as $reportChart) {
				$chartValues = explode('${dp}', $reportChart);
				$reportChartsJson .= '{"data":{"field":"'.$chartValues[0].'","label":"'.$chartValues[1].'","function":"'.$chartValues[2].'","display":"'.$chartValues[3].'","type":"'.$chartValues[4].'","index":"'.$chartValues[5].'","related":'.$chartValues[6].'}},';
			}
			$reportChartsJson = substr($reportChartsJson, 0, -1);
			$reportChartsJson .= '],"version":"'.substr($chartVersion, 3, 5).'"}';
			
			$reportChartsJson = base64_encode(serialize(json_decode($reportChartsJson, true)));

			return $reportChartsJson;
			
		}
			
	}
	
	
	static public function migrateReportTypeToSerialized($reportType) {
		
		global $current_user, $db;

		$storedReportType = explode('${dp}', $reportType);
		
		if (count($storedReportType) == 1) {
			
			return $reportType;
			
		} else {
			
			$storedKey = (!asol_CommonUtils::isDomainsInstalled()) ? 'base' : $current_user->asol_default_domain;
			
			$txtFile = null;
			$xmlFiles = null;
			$subGroups = null;
			$types = null;
			
			$storedReportTypeUrl = explode('&', $storedReportType[1]);
			foreach ($storedReportTypeUrl as $storedReportTypeUrlParam) {
				$storedReportTypeUrlParamValues = explode('=', $storedReportTypeUrlParam);
				if ($storedReportTypeUrlParamValues[0] == 'txtFile')
					$txtFile = $storedReportTypeUrlParamValues[1];
				else if ($storedReportTypeUrlParamValues[0] == 'xmlFiles')
					$xmlFiles = explode('|', $storedReportTypeUrlParamValues[1]);
				else if ($storedReportTypeUrlParamValues[0] == 'subGroups')
					$subGroups = explode('|', $storedReportTypeUrlParamValues[1]);
				else if ($storedReportTypeUrlParamValues[0] == 'types')
					$types = explode('|', $storedReportTypeUrlParamValues[1]);
			}
			
			$chartFiles = array();
			
			foreach ($xmlFiles as $chartKey=>$xmlFile) {
				if (!empty($xmlFile)) {
					$chartFiles[] = array(
						'file' => $xmlFile,
				        'type' => $types[$chartKey],
				        'subGroups' => $subGroups[$chartKey],
					);
				}
			}
			
			$reportTypeArray[$storedKey] = array(
				'infoTxt' => $txtFile,
				'chartFiles' => $chartFiles
			);
			
			$storedReportTypeSerialized = base64_encode(serialize($reportTypeArray));
		
			return $storedReportTypeSerialized;

		}
		
	}
	
	static private function getEnumReferenceForEnumField($module, $field) {
		
		$field_defs = BeanFactory::newBean($module)->field_defs;
		
		if (!empty($field_defs[$field]['options'])) {
	
			$enumOperator = 'options';
			$enumReference = $field_defs[$field]['options'];
	
		} else if (!empty($values['function'])) {
	
			$enumOperator = 'function';
			$enumReference = $field_defs[$field]['function'];
			
		} else {
	
			$enumOperator = '';
			$enumReference = '';
			
		}
		
		return array(
			'enumOperator' => $enumOperator,
			'enumReference' => $enumReference,
		);
		
	}
	
	
	static private function getTableModuleArray() {
		
		global $current_user;
		
		$acl_modules = ACLAction::getUserActions($current_user->id);
		
		//Get an array of table names for admin accesible modules
		$modulesTables = Array();
		
		foreach($acl_modules as $key=>$mod){
			$tableName = BeanFactory::newBean(BeanFactory::getObjectName($key))->table_name;
			$tableName = ($tableName == false ? BeanFactory::newBean($key)->table_name : $tableName);
			$tableName = (empty($tableName) ? strtolower($key) : $tableName); 
			$modulesTables[$tableName] = $key;
		}
		
		return $modulesTables;
		
	}
	
	static private function unescapeSpecialCases($input) {
		
		$input = str_replace('\\_', '_', $input);
		return $input;
		
	}
	
	static public function migrateReportsCharts($chartsDetail) {

		$isJson = json_decode(rawurldecode($chartsDetail), true);
		
		if (!isset($isJson)) {

			$currentCharts = unserialize(base64_decode($chartsDetail));
		
			if (!empty($currentCharts['charts'])) {
				
				$update = false;
		
				foreach ($currentCharts['charts'] as & $currentChart) {
						
					if (isset($currentChart['data']['field']) && isset($currentChart['data']['index'])) {
		
						$currentChart['data']['yAxis'] = array($currentChart['data']['field']);
						unset($currentChart['data']['field']);
						$currentChart['data']['yIndex'] = $currentChart['data']['index'];
						unset($currentChart['data']['index']);
		
						if (!empty($currentChart['data']['subcharts'])) {
								
							foreach ($currentChart['data']['subcharts'] as & $currentSubChart) {
		
								if (isset($currentSubChart['data']['field']) && isset($currentSubChart['data']['index'])) {
										
									$currentSubChart['data']['yAxis'] = array($currentSubChart['data']['field']);
									unset($currentSubChart['data']['field']);
									$currentSubChart['data']['yIndex'] = $currentSubChart['data']['index'];
									unset($currentSubChart['data']['index']);
										
								}
		
							}
								
						}
		
						$update = true;
		
					}
	
					if (isset($currentChart['config']['colorPalette'])) {
							
						$currentChart['config'] = array(
							'colors' => $currentChart['config']['colorPalette']
						);
							
						if (!empty($currentChart['data']['subcharts'])) {
					
							foreach ($currentChart['data']['subcharts'] as & $currentSubChart) {
									
								if (isset($currentSubChart['config']['colorPalette'])) {
					
									$currentSubChart['config'] = array(
										'colors' => $currentSubChart['config']['colorPalette']
									);
					
								}
									
							}
					
						}
						
						$update = true;
							
					}
					
				}
		
				if ($update) {
					return base64_encode(serialize($currentCharts));
				}
		
			}
			
		}
		
		return $chartsDetail;
		
	}
	
	static public function migrateReportScheduledTypeToJson($scheduledType) {
		
		$currentScheduledType = explode('${dollar}', $scheduledType);
		
		if ($scheduledType !== 'email' && in_array($currentScheduledType[0], array('email', 'app'))) {
		
			if ($currentScheduledType[0] == 'email') {
				$scheduledType = 'email';
			} else if ($currentScheduledType[0] == 'app') {
				$reportScheduledApp = explode('${pipe}', $currentScheduledType[1]);
				$reportScheduledFixedParameters = explode('${dp}', $reportScheduledApp[2]);
				$fixedParamsArray = array();
				foreach ($reportScheduledFixedParameters as $currentFixedParameter) {
					$currentFixedParameterValues = explode('${comma}', $currentFixedParameter);
					$fixedParamsArray[] = array(
						'name' => $currentFixedParameterValues[0],
						'internal' => $currentFixedParameterValues[1],
						'value' => $currentFixedParameterValues[2],
					);
				}
				$appParameters = array(
					'application' => $reportScheduledApp[0],
					'url' => $reportScheduledApp[1],
					'parameters' => array(
						'fixed' => $fixedParamsArray,
						'external' => $reportScheduledApp[3],
					),
					'clean' => array(
						'headers' => ($reportScheduledApp[4] == '1'),
						'quotes' => ($reportScheduledApp[5] == '1'),
					)
				);
				$scheduledType = 'app:'.urlencode(json_encode($appParameters));
				
			} else {
				$scheduledType = 'email';
			}
		
		}
		
		return $scheduledType;
		
	}
	
	
	static public function migrateReportScheduledTasksToJson($scheduledTask) {

		if (rawurlencode(rawurldecode($scheduledTask)) === $scheduledTask) {
		
			return $scheduledTask;
		
		} else if ($scheduledTask !== '${GMT}') {

			$currentTasksGmt = explode('${GMT}', $scheduledTask);
			
			$currentTasks = explode('|', $currentTasksGmt[0]);
			$currentTZ = (empty($currentTasksGmt[1]) ? date("Z")/3600 : null);
		
			$newFormatTasksData = array();
		
			foreach ($currentTasks as $singleTask) {
		
				$taskValues = explode(':', $singleTask);
				$currentTime = explode(',', $taskValues[3]);
				$calculatedHour = ($currentTime[0] - (isset($currentTZ) ? $currentTZ : 0));
				$unformattedHour = ($calculatedHour < 0 ? $calculatedHour+24 : $calculatedHour);
				$currentHour = (strlen($unformattedHour) == 1 ? '0'.$unformattedHour : $unformattedHour);
				$currentMinute = $currentTime[1];
		
				$newFormatTasksData[] = array(
					'name' => $taskValues[0],
					'range' => array(
						'type' => $taskValues[1],
						'value' => ($taskValues[1] == 'daily' ? null : $taskValues[2])
					),
					'time' => $currentHour.':'.$currentMinute,
					'end' => $taskValues[4],
					'status' => $taskValues[5]
				);
		
			}
		
			$newFormatTasks = array(
				'data' => $newFormatTasksData,
				'offset' => (empty($currentTasksGmt[1]) ? date("Z") : $currentTasksGmt[1]*3600),
			);
		
			return rawurlencode(json_encode($newFormatTasks));
			
		} else {
			
			return null;
			
		}
		
	}
	
	
	
	static public function migrateReportEnumFormats($currentValues, $type) {
	
		$modifiedReport = false;
		
		$isJson = json_decode(rawurldecode($currentValues), true);
		
		if (!isset($isJson)) {
		
			if ($type == 'report_fields') {
				
				$currentFields = unserialize(base64_decode($currentValues));
				foreach ($currentFields['tables'][0]['data'] as & $singleField) {
		
					$currentFormatType = $singleField['format']['type'];
					$currentFormatExtra = $singleField['format']['extra'];
					$currentTemplates = $singleField['templates'];
					if (!isset($singleField['format']['extra']['data'])) {
						if (($currentFormatType == 'enum') && !empty($currentFormatExtra)) {
							$singleField['format']['extra'] = array(
								'mode' => '',
								'data' => (isset($currentTemplates['enum']) ? 'hasTemplate' : $singleField['format']['extra'])
							);
							$modifiedReport = true;
						}
					}
		
				}
				
				if ($modifiedReport) {
					$currentValues = base64_encode(serialize($currentFields));
				}
					
			} else if ($type == 'report_filters') {
		
				$currentFilters = unserialize(base64_decode($currentValues));
				foreach ($currentFilters['data'] as & $singleFilter) {
		
					$currentOptions = $singleFilter['userOptions'];
					$currentTemplates = $singleFilter['templates'];
					if (!isset($singleFilter['userOptions']['data'])) {
						if (!empty($currentOptions) || (isset($currentTemplates['enum']))) {
							$singleFilter['userOptions'] = array(
								'mode' => '',
								'data' => (isset($currentTemplates['enum']) ? 'hasTemplate' : $singleFilter['userOptions'])
							);
							$modifiedReport = true;
						}
					}
		
				}
				
				if ($modifiedReport) {
					$currentValues = base64_encode(serialize($currentFilters));
				}
					
			}
			
		}
		
		return $currentValues;
	
	}
	
	static public function migrateReportTypeToJson($currentValue) {
		
		$reportType = json_decode(rawurldecode($currentValue), true);
		if (!isset($reportType)) {
			$reportTypeExploded = explode(':', $currentValue);
			$reportTypeJson = array(
				'type' => $reportTypeExploded[0]
			);
			if ($reportTypeExploded[0] == 'stored') {
				$reportTypeJson['data'] = $reportTypeExploded[1];
			}
			$currentValue = rawurlencode(json_encode($reportTypeJson));
		}
		
		return $currentValue;
		
	}
	
	static public function migrateReportExternalTable($currentValue, $database) {
		
		if (($database >= '0') && self::endsWith($currentValue, '(External_Table)')) {
			$currentValue = str_replace(' (External_Table)', '', substr($currentValue, -1*(strlen($currentValue) - strpos($currentValue, '.') - 1)));
		}
		
		return $currentValue;
		
	}
	
	static public function migrateReportDataSource($currentValue, $database, $audit) {
		
		if (isset($currentValue)) {
			
			$dataSource  = array(
				"type" => "0",
				"value" => array(
					"database" => $database,
					"module" => $currentValue
				)
			);
			if ($database == '-1') {
				$dataSource['value']['audit'] = $audit;
			}
			$currentValue = rawurlencode(json_encode($dataSource));
			
		}
		
		return $currentValue;
			
	}
	
	function migrateReportsBase64Columns($currentValue) {
		
		if (base64_encode(base64_decode($currentValue)) === $currentValue) {
			$currentValue = rawurlencode(json_encode(unserialize(base64_decode($currentValue))));
		}
		
		return $currentValue;
		
	}
	
	static private function endsWith($haystack, $needle) {
		
		$length = strlen($needle);
		return $length === 0 || (substr($haystack, -$length) === $needle);
		
	}
	
}